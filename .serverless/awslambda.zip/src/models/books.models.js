class Book{
    constructor(id,title,author,isAvailable){
        this.id=id;
        this.title=title;
        this.author= author;
        this.isAvailable= isAvailable;
    }
}

module.exports = Book;