class Book{
    constructor(id,name,author,isAvailable){
        this.id=id;
        this.name=name;
        this.author= author;
        this.isAvailable= isAvailable;
    }
}

module.exports = Book;